# Système de mise à jour

L'extension vérifie au démarrage, puis toutes les 5 minutes, si `manifest.json` sur la branche `main` de [kiricoucou/uca-extension](https://github.com/kiricoucou/uca-extension) a un numéro de version supérieur à celui actuellement chargé. Si oui, un écran ou un bandeau de mise à jour apparaît (popup et agenda, quel que soit le design choisi) avec le numéro de version et un bouton **Mettre à jour**.

## Comment la nouvelle version s'installe

- **Chrome, Edge, Brave (dossier chargé à la main) :** l'extension peut se mettre à jour seule si tu lui donnes une fois accès à son dossier ; elle vérifie la signature du paquet avant de remplacer ses fichiers.
- **Sinon (Firefox, par exemple) :** utilise le script de mise à jour ou remplace les fichiers, puis recharge l'extension.
- **Version installée par un magasin :** le navigateur s'en charge.
- **Application Android :** les pages se mettent à jour toutes seules ; quand le code de l'application change, elle propose d'installer le nouvel APK.

# Historique des versions

## 1.47.3 — app Android 1.4.34 : notes Moodle dans l'application, bus et tram en direct

- **Moodle dans l'application Android :** dans la fenêtre Notes, « Chercher sur Moodle » lit tes notes sur Moodle (« Me connecter à Moodle » la première fois) ; chaque note reste à valider ou à refuser. Après la synchro d'Odin, la recherche se fait aussi toute seule si ta session Moodle est ouverte, avec une notification pour les nouvelles notes.
- **Application Android, données conservées :** elle n'efface plus à l'ouverture un relevé, un emploi du temps, des absences ou des devoirs dont les noms ressemblaient à ceux de la démo.
- **Un seul pilote de mise à jour :** il s'installe au premier lancement ; ensuite « Appliquer la mise à jour » le lance directement, sans nouveau téléchargement.
- **Transports partout :** les passages marchent maintenant sans extension : site, iPhone, app web, application Android et extension.
- **Données officielles :** horaires et temps réel viennent des données ouvertes de T2C (transport.data.gouv.fr, Licence Ouverte). « En direct » = temps réel ; « Prévu » = horaire officiel.
- **Plus de coupure :** si le temps réel ne répond pas, les horaires prévus restent affichés, et la page le dit.
- **Moins d'autorisations :** l'extension ne demande plus d'accès aux sites t2c.fr.
- **Nouvel APK 1.4.34 :** à installer par-dessus l'ancien.

## 1.47.2 — app Android 1.4.33 : transports plus clairs, notes Moodle expliquées

- **Transports refaits :** uniquement de vrais passages (« En direct » ou « Prévu », sinon « Indisponible »). Les anciens horaires, trajets, trains et covoiturages inventés sont supprimés ; pour ceux-là, des liens vers les sites officiels.
- **Notes Moodle expliquées :** une nouvelle page simple (comment la note, le barème, le commentaire et la matière sont trouvés, et ce que deviennent tes données), reliée à l'aide et à l'accueil du site.
- **Première connexion :** une seule question, « Odin, Moodle ou les deux ? ». Ta réponse reste sur ton appareil.
- **Notes Moodle corrigées :** le menu des matières ne se referme plus tout seul ; une note validée pendant une recherche n'est plus effacée ; un avertissement signale une note déjà présente via Odin.
- **Nouvel APK 1.4.33 :** à installer par-dessus l'ancien. L'écran Transports y affiche les vrais passages et ouvre les sites officiels dans ton navigateur.
- Une seule extension : l'ancienne « Édition Moodle » de test est retirée. Les paquets installés par un magasin ont aussi un bouton « Vérifier la mise à jour ».

## 1.47.1 — app Android 1.4.32 : « Notes Moodle » activé par défaut

- **Nouveau : tes notes Moodle dans ton relevé.** L'extension lit tes notes sur Moodle (bouton « Chercher sur Moodle » de la fenêtre Notes, et à chaque synchro) et te propose chaque nouvelle note avec sa matière et son coefficient : tu la valides ou tu la refuses, rien n'entre dans tes moyennes sans ton accord. Les notes validées restent modifiables, les refusées vont à la corbeille (restaurables), une barre de progression en pourcentage suit la recherche.
- Le réglage **Notes Moodle** est **activé par défaut** (Paramètres pour le désactiver). Sur l'app Android et l'app web, les notes Moodle validées arrivent avec le partage chiffré.
- Synchro automatique : si tu n'es pas connecté à Moodle dans ce navigateur, elle ne fait rien (aucun onglet ouvert pour rien) ; le bouton « Chercher sur Moodle » essaie toujours et propose « Me connecter à Moodle ».

## 1.47.0 — app Android 1.4.31 : notes Moodle avec validation, corbeille, fenêtres déplaçables

- **Notes Moodle** (Paramètres → « Notes Moodle », désactivé par défaut) : à chaque synchro, l'extension lit tes cours et tes notes sur Moodle avec ta session (`core/moodle.js`, `background.js`). Les cours sont retrouvés dans ta page Notes à chaque fois : aucun identifiant de cours ou d'année n'est codé en dur (`moodle*.uca.fr`).
- **Rien n'entre dans les moyennes sans ton accord** : chaque nouvelle note donne une notification « Nouvelle note détectée sur Moodle : matière, note / barème, commentaire » avec **Valider la note** et **Refuser la note** (Chrome / Edge de bureau ; ailleurs, le même bandeau est en haut de la fenêtre Notes). Une matière est toujours proposée par défaut (d'après le code du cours R1.07, SAE1.05…, sinon d'après son nom, sinon la première du relevé, signalée « à vérifier ») ; c'est toi qui confirmes ou corriges la matière et le coefficient avant l'ajout. Dans la notification, **Valider la note** ouvre la fenêtre Notes sur la carte de cette note (rien n'est ajouté sans ta confirmation) ; **Refuser la note** ignore la note tout de suite. Confirmer ajoute la note au tableau (ramenée sur 20) et recalcule moyennes et historique. Refuser l'ignore pour toujours, sauf si Moodle change la valeur (contrôles fictifs). Les décisions se défont dans « Notes Moodle déjà traitées ».
- **Choix de la matière** : menu à couleurs avec recherche, matières rangées par UE, « Créer une nouvelle matière » toujours en tête. La matière du relevé qui porte le même code est recommandée ; sinon la plus proche par le nom du cours ; si le cours ne ressemble à aucune matière, c'est « Créer une nouvelle matière » (avec un nom proposé) qui est recommandé. Une matière créée apparaît dans une UE « Matières ajoutées (Moodle) », compte dans la moyenne, et se propose ensuite pour les notes suivantes. Couleurs : bleu = recherche / en attente, vert = validée, rouge = refusée ou ignorée.
- **Fenêtres de la fenêtre Notes** : « Notes Moodle déjà traitées » s'ouvre dans une petite fenêtre à droite de l'écran (modifiables, bouton Fermer en haut à droite) : le graphique du panneau Notes reste visible à gauche. Le panneau Notes se déplace par sa barre (souris ou flèches), se redimensionne par le coin bas droit, mémorise sa position et sa taille (double-clic sur la barre : position d'origine) et s'ouvre à 10 px sous la barre « Semaine du … ». À côté de « Chercher sur Moodle » : « Dernière recherche : il y a 7 minutes » (secondes, minutes, heures, jours). Tests : `tests/moodle.py` (Playwright) et `tests/moodle_selenium.py` (Selenium).
- **Corbeille** : la fenêtre « Notes Moodle déjà traitées » ne montre que les notes **validées** (modifiables). Une note refusée ou ignorée va automatiquement à la **corbeille** (bouton 🗑 juste à côté de « Fermer »), qui la garde en ligne compacte avec **Restaurer** (retour en attente, avec ses réglages) et **Supprimer** (définitif : jamais redemandée tant que Moodle ne change pas la note) ; **Vider la corbeille** demande une confirmation. La barre de progression de la recherche affiche un **pourcentage** (« 33 % ») en plus du cours en cours. Statut ajouté : `deleted` (`core/moodle.js`).
- **App Android et app web (PWA)** : mêmes pages que l'extension. La recherche sur Moodle se fait depuis l'extension (un navigateur isole les cookies de Moodle) ; les notes Moodle validées, la corbeille et les choix de matière voyagent avec le lien de partage chiffré, le QR ou le fichier `.ucasync` (clé `uca_moodle`), et apparaissent dans le tableau des notes de l'app, où l'on peut les valider, refuser, restaurer et modifier. Panneau Notes déplaçable et redimensionnable sur ordinateur ; sur téléphone, les fenêtres restent des feuilles en bas d'écran.
- Premier passage : une seule notification de synthèse, jamais une rafale. Session Moodle expirée : problème signalé, notes déjà vues conservées.
- Nouvelle permission d'accès : `https://moodle2026.uca.fr/*` (et 2027, 2028 : Chrome refuse un motif `moodle*`) (l'extension rouvre donc une demande d'autorisation à la mise à jour). Tests : `tests/moodle.py`.

## 1.40.0 — fiabilité (lot 1)

Déjà en place avant cette version (vérifié, non refait) : détection des pannes d'Odin pour notes et absences, page méconnaissable signalée dans les panneaux Notes/Absences, journal de diagnostic copiable (Paramètres → Diagnostic), pages Odin factices (`tests/pages/`), CI GitHub Actions.

Ajouté :
- **Bandeau « Données vieilles de X h »** dans l'extension (les 4 designs) quand la dernière synchro a plus de 24 h, avec un bouton **Resynchroniser** (même chemin que « Synchroniser »). L'app avait déjà son rappel (lien vers l'import).
- **Emploi du temps méconnaissable** : si Odin répond mais qu'aucun cours n'est reconnu alors que l'ancien emploi du temps en contient encore à venir, l'ancien est conservé (jamais écrasé par du vide), un message clair s'affiche et le problème est noté dans le journal. Une vraie semaine vide (rien à venir avant) reste acceptée.
- Accessibilité : liste des cours du téléphone atteignable au clavier, contraste des cours passés corrigé (a11y 20/20).
- Tests : `tests/lots.py` (bandeau dans les 4 designs, téléphone et ordinateur), `tests/scrape.py` étendu à l'emploi du temps.

## 1.41.0 — fonctions étudiant (lot 2)

Déjà en place (vérifié, non refait) : rappel avant chaque cours avec salle et enseignant (délai réglable), détection des changements d'emploi du temps (cours ajouté, annulé, déplacé, salle changée) avec notification, alerte d'absences réglable, simulateur d'objectif, évolution des notes, export .ics (avec rappels), prochain cours.

Ajouté :
- **Devoirs et examens** (bouton « Devoirs » après Notes dans les 4 designs, entrée du menu mobile) : liste de devoirs liée aux matières, avec date de rendu et compte à rebours, case à cocher, « Effacer les terminés » ; les examens de l'emploi du temps (Examen, DS, Partiel) y apparaissent tout seuls. Stockage local (`uca_tasks`), transmis dans les transferts chiffrés vers l'app, effacé par « Réinitialiser » (annulable).
- **Rappels la veille à 18 h** pour chaque devoir non terminé et chaque examen (réglage « Devoirs et examens la veille », extension).
- **Prochain cours / examen** : « Examen dans 3 h : … » quand c'est un examen, et « · Examen dans 2 jours » ajouté après le prochain cours (agenda et popup).
- **Pastille d'absences** sur le bouton Absences : orange à un pas du seuil réglé, rouge une fois atteint.
- **Objectifs de moyenne** (fenêtre Notes) : *projection du semestre* (moyenne générale selon la note obtenue sur tout le reste) et *matières à prioriser* (classées par effet possible sur la moyenne générale, avec la note à viser dans la matière).
- **Export .ics** : option « Ajouter mes devoirs à rendre » (événements journée entière, rappel la veille à 18 h).
- **App** : notification « prochain cours » épinglée (Paramètres, demande l'autorisation). Limite honnête : une page web ne peut pas se réveiller sans serveur de push, la notification se met à jour à chaque ouverture de l'app, retour au premier plan et chaque minute tant que l'app est ouverte, pas en continu.
- Pas de lien d'abonnement `.ics` automatique : il faudrait héberger l'emploi du temps sur un serveur, ce que le projet s'interdit ; le fichier reflète la dernière synchro, à réexporter après une synchro.
- Tests : `tests/lots.py` (devoirs dans les 4 designs, XSS, rappels, examen, absences, .ics), `tests/grades.py` (projection, priorités), `tests/pwa.py` (notification épinglée), a11y étendu à la fenêtre Devoirs.

## 1.42.0 — app / PWA (lot 3)

Déjà en place (vérifié, non refait) : manifeste installable avec icônes maskable et raccourcis, service worker « réseau d'abord » avec repli sur le cache, guide d'installation Android / iPhone au premier lancement, import par lien, QR ou fichier.

Ajouté :
- **Hors ligne complet** : l'installation met maintenant en cache tout ce que chaque design et chaque page référencent (scripts, styles, icônes SVG, polices, pages d'aide), pas seulement ce qui a déjà été ouvert. Test : on installe, on coupe le réseau sans rien ouvrir d'autre, puis les 4 designs, les réglages, l'aide et le guide s'ouvrent sans requête échouée. Cache passé en `uca-app-v5`.
- **Guide d'installation rappelable** : entrée « Installer l'app sur l'écran d'accueil » dans le menu mobile et le panneau Liens (tant que l'app est dans un navigateur) ; le guide s'affiche même si un design est déjà choisi (`?force=1`) ; conseils selon le navigateur (iPhone hors Safari : « ouvre la page dans Safari » ; Firefox Android : menu ⋮ → Installer).
- **Partage en image** (panneau Exporter, tous les designs) : image PNG du jour ou de la semaine dessinée localement (aucune requête, sans les notes personnelles), envoyée par la feuille de partage native quand le navigateur sait partager un fichier, sinon enregistrée.
- Design bulletin : il lui manquait ses icônes SVG (page d'aide cassée hors ligne comme en ligne), ajoutées en vert.
- Doc : `store/PUBLIER.md` explique ce qui dépend de la publication AMO pour la synchro directe sur Firefox Android, et ce qui reste à tester sur un vrai téléphone.

## 1.46.66 — page Statut : détecter la version et mettre à jour depuis le site

- Nouvelle page **statut.html** (menu « Mettre à jour ») : un bouton « Activer la détection » ; l'extension demande alors elle-même à l'utilisateur si le site peut lire sa version (fenêtre dessinée par l'extension, seuls les vrais clics comptent, autorisation mémorisée et retirable depuis la page).
- Si une version plus récente est en ligne : « Mettre à jour ». Le site demande l'autorisation de communiquer avec l'extension, de télécharger la version officielle (signature vérifiée) et de modifier le dossier de l'extension ; l'extension redemande son accord, l'utilisateur choisit le dossier, la page écrit les fichiers avec une barre de progression, puis recharge l'extension, sans passer par le fichier .bat.
- Refus (ou Firefox, sans accès au dossier) : redirection vers le fichier de mise à jour de son système (.bat, .command, .sh).
- Les extensions plus anciennes que cette version sont reconnues (« version ancienne ») et peuvent aussi être mises à jour depuis la page ; il reste alors à cliquer « Recharger » dans la page des extensions.

## 1.46.65 — app Android 1.4.30 : bouton « Forcer la mise à jour »

- APK : nouveau bouton « Forcer la mise à jour » dans les Préférences (section mise à jour). Il retélécharge et réinstalle le paquet des pages publié sur GitHub même si l'application se croit déjà à jour (signature toujours vérifiée), puis recharge l'agenda.

## 1.46.64 — app Android 1.4.29 : la flèche du cours disparaît à l'appui sur le menu

- Quand un cours est désigné par la flèche animée (depuis Examens ou Devoirs), un appui sur le bouton menu la fait disparaître tout de suite, même si ses 6 secondes ne sont pas écoulées. Extension, app web et APK.

## 1.46.63 — Paramètres : tout supprimer et remettre à blanc

- Nouveau bouton dans les Paramètres : « Tout supprimer et remettre à blanc ». Il efface toutes les données de l'extension sur l'appareil (cours, notes, absences, réglages, design, code de partage) après une confirmation en deux clics, puis revient au choix du design.

## 1.46.62 — QR de la page appli cliquable

- Sur la page Télécharger l'appli, le QR code est cliquable : il s'ouvre en grand pour être scanné facilement depuis l'écran.

## 1.46.61 — lien /app/ : choix page ou agenda

- Ouvrir le lien de l'agenda en ligne demande d'abord : consulter la page ou accéder à l'agenda en ligne, avant d'afficher quoi que ce soit.

## 1.46.60 — app Android 1.4.28 : notes cliquables

- Notes : chaque note avec sa barre de progression est cliquable (ordinateur et téléphone) et ouvre un détail : note, coefficient, moyenne de la classe, meilleure et moins bonne note. Dans le graphique d'une matière, les barres et les libellés ouvrent aussi ce détail. La croix du détail (ou un clic à côté, ou Échap) ferme seulement le détail : le panneau Notes reste ouvert.

## 1.46.59 — app Android 1.4.27 : sécurité, 9 failles corrigées

- Sécurité (audit attaque/défense) : le pont de l'extension ne répond plus aux pages locales (file://, localhost) ni aux iframes, seulement au site officiel, avec un délai entre deux ouvertures d'agenda ; la version distante est validée avant d'être affichée dans une commande ; le partage de fichier vers la PWA refuse les sites tiers et les fichiers trop gros ; l'import de données est borné ; la mise à jour automatique refuse un retour à une version plus ancienne ; les installateurs Windows et macOS valident la version lue en ligne ; des notes internes ne sont plus publiées sur le site ; l'application ignore les adresses et seuils venant de version.json. Aucun changement visible.

## 1.46.58 — sécurité : mises à jour automatiques signées

- Sécurité : le paquet de l'extension téléchargé par la mise à jour automatique (Chrome, Edge) est maintenant signé par le projet (RSA-SHA256, même clé que l'application). L'extension vérifie la signature avant d'écrire le moindre fichier : un paquet modifié en route, remplacé ou sans signature est refusé. Aucun changement visible.

## 1.46.57 — site plus clair : menu décrit, recherche, page appli, pilote automatique

- Site : menu hamburger avec toutes les pages et une courte description sous chacune ; recherche globale dans l'en-tête (bouton Rechercher ou touche /) ; nouvelle page « Télécharger l'appli » (appli.html : Android APK ou iPhone, QR code pour envoyer le lien) ; page « Pilote automatique » refaite (assistant en 2 questions : ordinateur et navigateur, bouton unique, rechargement adapté, « Ça ne marche pas ? » en un clic) ; accueil « Que veux-tu faire ? » en 6 cartes ; introductions des pages raccourcies.

## 1.46.56 — script de mise à jour plus rapide

- Script de mise à jour Windows : plus de barre de progression PowerShell (téléchargement bien plus rapide). Vérifié en vrai sur Windows avec les trois dossiers Chrome, Edge et Firefox.

## 1.46.55 — documentation de la commande de mise à jour

- Page mise-a-jour.html : nouvelles sections « Tout en une commande » (arguments /browser, /os, /version, /yes), « Plusieurs navigateurs, plusieurs dossiers » et FAQ complétée. La liste de confirmation du script Windows affiche le nom du navigateur avant le chemin (visible même quand le chemin est long).

## 1.46.54 — mise à jour : tous les navigateurs détectés

- Scripts de mise à jour (.bat, .sh, .command) : ils détectent les navigateurs (Chrome, Edge, Brave, Vivaldi, Firefox) et mettent à jour tous les dossiers rangés côte à côte (extension_uca_chrome, _edge, _firefox), en écrivant le nom de chaque navigateur. L'installateur Windows crée désormais un dossier par navigateur (extension_uca_edge, extension_uca_brave…). La page mise-a-jour.html explique comment recharger l'extension dans Chrome, Edge, Brave, Firefox et les autres navigateurs.

## 1.46.53 — commande de mise à jour complète

- Écran « Mise à jour obligatoire » : « Appliquer la mise à jour » télécharge le script de ton système (.bat, .command ou .sh) et affiche la commande complète à copier dans un terminal, avec le navigateur, l'OS et la nouvelle version. Les scripts acceptent --browser / --os / --version / --yes (Windows : /browser /os /version /yes), ne regardent que le navigateur demandé, vérifient la version obtenue puis rouvrent ce navigateur sur la nouvelle version de l'extension.

## 1.46.52 — installateurs ouvrent l'agenda, note devoirs

- Installateurs (Windows, macOS, Linux) : l'agenda de l'extension s'ouvre automatiquement dans chaque navigateur où elle a été installée (Chrome, Edge, Firefox…), via la page de remerciement. Devoirs : une ligne précise que les devoirs ajoutés à la main restent en local et ne sont pas synchronisés avec les autres appareils.

## 1.46.51 — mise à jour : sous-dossiers, script, bouton Appliquer

- Mise à jour par script (.bat, .sh, .command) : si le dossier choisi est le mauvais, le script cherche le manifest.json dans les sous-dossiers, puis dans les dossiers voisins et au-dessus. Quand l'extension détecte une mise à jour, la page de téléchargement ne télécharge plus le ZIP mais le script de ton système (Windows, macOS ou Linux). Écran « Mise à jour obligatoire » : nouveau bouton « Appliquer la mise à jour » qui recharge l'extension pour qu'elle relise ses fichiers (Firefox garde sinon l'ancienne version).

## 1.46.50 — bouton Ouvrir l'agenda sur la page de remerciement

- Page de remerciement (merci.html) : nouveau bouton « Ouvrir l'agenda de l'extension » (visible quand l'extension est détectée), pour ouvrir l'agenda même si l'icône n'est pas épinglée dans la barre du navigateur.

## 1.46.49 — barre de navigation de la page 404

- Page 404 : la barre de navigation (Accueil + menu) s'affiche de nouveau en haut de la page, sur toute la largeur, au lieu d'être au milieu à gauche.

## 1.46.48 — page mise-a-jour : style

- Page mise-a-jour.html : icônes à côté des titres d'étapes et titres plus grands (hiérarchie plus nette).

## 1.46.47 — scripts de mise à jour Windows, macOS, Linux ; téléphone

- Mise à jour de l'extension par script : maj-extension.bat (Windows), maj-extension.command (macOS) et maj-extension.sh (Linux) retrouvent tout seuls le dossier de l'extension dans Chrome, Edge, Brave, Vivaldi ou Firefox, te le montrent (« Ouvrir le dossier », puis « Valider ») et mettent l'extension à jour s'il existe une nouvelle version. Nouvelle page mise-a-jour.html qui les présente étape par étape.
- Accueil sur téléphone : un seul bouton hamburger (le menu complet) ; dans la démo, un doigt fait défiler la page et deux doigts font défiler l'app.

## 1.46.46 — app Android 1.4.26 : contraste du badge « En cours » (Lumen)

- Design Lumen : le vert du badge « En cours » et du statut « justifiée » est plus foncé en thème clair, pour un contraste lisible (norme d'accessibilité), sur l'extension, l'app web et l'APK.

## 1.46.45 — installer et ouvrir la PWA pour de vrai

- Page app-download.html : la page est maintenant installable (manifeste et service worker), donc « Installer via le web » lance la vraie fenêtre d'installation de Chrome au lieu d'ouvrir une page. Une fois l'app installée, le bouton devient « Ouvrir l'app installée » et, sur Android, ouvre l'app (adresse intent:) plutôt qu'un onglet. Même comportement pour « Ouvrir l'app installée » sur l'accueil.

## 1.46.44 — page app-download : titres accessibles

- Page app-download.html : la hiérarchie des titres ne saute plus de niveau (h1 puis h2), pour les lecteurs d'écran.

## 1.46.43 — app Android 1.4.25 : 25 widgets, nouvelle page d'installation de l'app

- App Android : 25 widgets pour l'écran d'accueil (prochain cours, journée, 3 jours, charge de la semaine, devoirs, examens, moyenne, graphique des notes, absences, connexion…). Toucher un widget ouvre l'écran utile ; « Connexion » et « Synchronisation » portent un bouton. Les mêmes widgets existent dans l'app web : écran « Mes widgets » (ajout, retrait, ordre).
- Nouvelle page app-download.html (Installer l'app) : choix de l'appareil puis du système, installateur automatique ou ZIP avec tutoriel en images, APK avec confirmation et PWA « non recommandée » sur Android, App Store indisponible et PWA guidée sur iPhone.
- Page de téléchargement de l'extension : bouton « Voir le tutoriel en images » plus visible et animé, étapes plus larges avec moins de texte.

## 1.46.42 — app Android 1.4.24 : session gardée en arrière-plan, aide à l'installation guidée

- App Android : la connexion à Odin est gardée. Quitter l'app ne déconnecte pas ; un contrôle silencieux toutes les 30 minutes garde la session vivante (interrupteur dans les réglages, état du dernier contrôle affiché). Aucun mot de passe ni code 2FA n'est enregistré ; le choix « navigateur de confiance » de la double authentification est respecté et seule « Se déconnecter » efface les cookies.
- Aide à l'installation : pour l'installateur automatique, un menu choisit le système (Windows, macOS, Linux) et une fiche à droite propose le bon fichier ; pour le ZIP, le bouton « Installer le ZIP » ouvre une fenêtre avec la barre de pourcentage puis « Vous avez bien téléchargé le ZIP ? ».

## 1.46.41 — page d'accueil : boutons d'installation

- Accueil du site : « Comment l'installer » (extension) ouvre la page installation.html et « Installer l'app » ouvre install.html ; si l'app est déjà installée sur l'appareil, une fenêtre demande d'ouvrir l'app installée ou de revoir la page d'installation.

## 1.46.40 — app Android 1.4.23 : « Aujourd'hui » le week-end et notes à barème en violet/rose

- Vues 5 et 6 jours : un samedi ou un dimanche, « Aujourd'hui » (bouton, menu et touche T) affiche la semaine suivante au lieu de la semaine qui vient de finir ; même chose à l'ouverture et en passant à ces vues. La vue Semaine ne change pas.
- Notes à barème (sur 12, sur 25…) : le chiffre de la note est violet tant que le barème n'est pas confirmé, rose ensuite, dans le tableau comme dans la liste sous le graphique (le rouge de l'ancienneté l'emportait). La barre garde la couleur de la note.

## 1.46.39 — Dossier d'installation par défaut sur le Bureau

- Les installateurs (Windows, Mac, Linux) et les guides placent l'extension dans Bureau/extension_uca_chrome (et extension_uca_firefox) : un dossier que Chrome et Edge acceptent pour la mise à jour en un clic (AppData, ~/Library et ~/.local sont refusés).

## 1.46.38 — verrou de mise à jour adapté à Firefox

- **Firefox : le verrou « Mise à jour obligatoire » explique le bon parcours** (lancer `maj-extension.bat` sur le dossier de l'extension, puis recliquer sur le bouton) au lieu de parler de `chrome://extensions` et du choix d'un dossier.

## 1.46.37 — mise à jour vérifiée de bout en bout (Chrome, Edge, Firefox)

- Version de contrôle : mise à jour automatique revérifiée sur Chrome, Edge et Firefox après les corrections de la 1.46.36. Aucun changement de code.

## 1.46.36 — mise à jour : le dossier choisi est mémorisé, Firefox pris en charge par maj-extension.bat

- **Chrome / Edge : le dossier de l'extension choisi une fois n'est plus oublié.** Quand Chrome retire l'autorisation d'écriture (rechargement de l'extension, redémarrage), un clic sur « Télécharger et appliquer » redemande seulement l'autorisation au lieu de rouvrir la boîte « Sélectionner un dossier ». **Firefox :** `maj-extension.bat` reconnaît un dossier Firefox, télécharge le paquet Firefox et indique `about:debugging` pour recharger.

## 1.46.35 — Firefox : vérification des mises à jour réparée

- **Firefox : l'extension se croyait « paquet de magasin » et ne vérifiait jamais les mises à jour** (le navigateur répond « ok » pour un fichier absent). La détection exige maintenant le contenu du fichier `store-build.txt` : les installations Firefox hors magasin voient enfin le verrou « Mise à jour obligatoire » et le bouton.

## 1.46.34 — mise à jour vérifiée sur Chrome, Edge et Firefox

- **Mise à jour testée de bout en bout sur Chrome, Edge et Firefox** (profils vierges) : détection de la nouvelle version puis application sans réinstaller. Chrome et Edge : bouton « Télécharger et appliquer » ; Firefox : parcours en deux temps (maj-extension.bat puis rechargement).

## 1.46.33 — installateurs : dossier par défaut compatible avec la mise à jour automatique

- **Dossier d'installation par défaut hors `AppData`, `~/Library` et `~/.local`** : Chrome refuse ces dossiers dans la boîte « Sélectionner un dossier », ce qui empêchait la mise à jour automatique en un clic. Les installateurs proposent maintenant `MyUCA` dans ton dossier personnel (Windows : `C:\Users\<toi>\MyUCA\extension`). Mise à jour automatique revérifiée de bout en bout sur un Chrome vierge.

## 1.46.32 — mise à jour automatique vérifiée de bout en bout

- **Mise à jour sans réinstaller, testée sur un Chrome vierge** : installation du ZIP en mode développeur, détection de la nouvelle version, bouton « Télécharger et appliquer la mise à jour », puis rechargement automatique. Aucun changement de code : seule la version change.

## 1.46.31 — dossier de l'extension propre (erreur « desktop.ini »)

- **Plus d'erreur « Cannot load extension with file or directory name desktop.ini »** au chargement : l'installateur (Windows, Linux, macOS) et `maj-extension.bat` suppriment eux-mêmes `desktop.ini`, `Thumbs.db` et `.DS_Store` du dossier de l'extension ; le ZIP contient `nettoyer-dossier-extension.bat` (double-clic à côté de `manifest.json`) et la page de téléchargement conseille un dossier dédié (pas Documents ni Bureau).

## 1.46.30 — app Android 1.4.22 : bouton « Relancer la demande d'installation »

- **APK : mise à jour obligatoire plus tolérante.** Quand on lance le téléchargement du nouvel APK puis qu'on annule l'installateur Android (« Ouvrir avec… » une seule fois / toujours, ou l'écran d'installation), le bouton devient « ↻ Relancer la demande d'installation » : un appui relance aussitôt la demande avec l'APK déjà téléchargé, sans quitter l'app ni retélécharger. Si le fichier a disparu, l'app le retélécharge.
- **Téléchargement plus sûr** : l'APK est écrit dans un fichier temporaire et ne prend son nom définitif qu'une fois complet.

## 1.46.29 — app Android 1.4.21 : logos par design, Studio, Lumen, calendrier à l'installation

- **Un logo SVG animé par design** (Animé, Professionnel, Carnet, Lumen, Studio), affichés sur chaque carte du choix de design et sur le bouton « Design » (agenda et popup). Respectent « réduire les animations ».
- **Design Studio** recalé sur un tableau de bord planning : colonnes hachurées, cartes à liseré coloré sur fond pastel, jour courant et bouton « Importer » en noir, coins très arrondis.
- **Design Lumen (verre liquide)** remplace Bulletin ; le choix mémorisé est migré automatiquement. Contrastes conformes WCAG AA.
- **Première installation** : le design par défaut (Studio) est appliqué et l'onglet du calendrier des cours s'ouvre tout seul, avec le bouton pour se connecter à Odin ; changer de design reste à un clic. L'installateur Linux ouvre aussi directement le calendrier.
- **Démo et navigation du site / de l'app web** : menu avec icônes, bascule clair / sombre, démo avec des cours jusqu'en septembre 2027 et des scénarios de changements.

## 1.46.28 — app Android 1.4.20 : notifications gérables, passé de la courbe, dates de sortie

- **Notifications gérables partout** : dans la cloche « Activité » de l'extension et dans l'écran Notifications de l'APK (comme dans l'app web) : garder (★, jamais supprimée), supprimer, tout supprimer sauf les gardées, filtres (toutes, non lues, gardées), lue / non lue (APK). Une notification supprimée ne revient pas à la synchro suivante.
- **Durée de conservation réglable** : 7, 14, 30 (défaut), 90 jours ou illimitée, dans Paramètres (extension), Préférences (APK et app web). Les notifications gardées ne sont jamais concernées.
- **Courbe d'évolution de la moyenne** : le passé est reconstruit à partir de la date de première vue de chaque note (plus besoin d'attendre plusieurs synchros) ; un seul point est dessiné quand il n'y en a qu'un ; le dernier point est toujours la moyenne actuelle.
- **APK** : le design Studio est proposé dans les Préférences.
- **Site** : les versions qui n'ont jamais eu de publication à leur nom (1.46.1, 1.46.7, 1.46.8) indiquent « livrée avec la 1.46.x » et la date de cette version, au lieu d'une date approchée.

## 1.46.27 — mise à jour automatique de l'extension

- **Mise à jour obligatoire = vraie mise à jour** : le bouton « Télécharger et appliquer la mise à jour » télécharge le ZIP publié, écrit les fichiers dans le dossier de l'extension (manifest.json en dernier) puis recharge l'extension. La première fois, le navigateur demande de choisir ce dossier et d'autoriser l'écriture ; il est ensuite mémorisé, et si l'autorisation est encore valable la mise à jour se fait même toute seule (sans clic) dès qu'une nouvelle version est détectée. Chemins hors dossier refusés, paquet qui n'est pas l'extension UCA refusé. Chrome, Edge, Brave, Chromium ; Firefox n'a pas cette API (étapes manuelles ou `install-linux.sh`).
- **Pages de téléchargement** : boutons ZIP / APK / les deux corrigés (taille et alignement).

## 1.46.26 — installateur Linux : page de connexion et icône visible

- **install-linux.sh** : à la fin, ouvre la page de l'extension pour se connecter (choix du design puis « Synchroniser »). Chrome-like : adresse calculée à partir du dossier, ouverte quand tu confirmes avoir chargé l'extension. Firefox : l'extension ouvre sa page toute seule au premier démarrage.
- **Firefox** : l'icône « Emploi du temps UCA » est épinglée dans la barre d'outils dès l'installation (`default_area`), donc visible et listée dans le menu Extensions.

## 1.46.25 — installateur Linux sans sudo

- **install-linux.sh** : sous Linux, `bash install-linux.sh` demande où installer (explorateur de fichiers si zenity / kdialog / yad), télécharge la dernière version, guide le chargement dans Chrome / Chromium / Brave / Edge et, pour Firefox, vérifie le profil et l'édition (mode développeur), demande l'accord puis installe. Aucun sudo ; paquet Firefox publié à côté du ZIP Chrome. Limite de Mozilla : Firefox « release » refuse les extensions non signées de façon permanente (chargement temporaire proposé) ; Developer Edition, Nightly et ESR acceptent l'installation permanente.

## 1.46.24 — app Android 1.4.19 : design Studio, notifications, session privée

- **Design Studio (nouveau, par défaut)** : tableau de bord clair, panneaux blancs très arrondis, cartes de cours pastel, accent marine ; mêmes fonctions que les 4 autres designs. Appliqué à l'extension, à l'app web, à l'APK, au site et aux pages de téléchargement. Dans l'app web, le menu (à gauche sur ordinateur, en bas sur téléphone) suit maintenant le design choisi.
- **Notifications (app)** : marquer lue / non lue, **garder** (reste même quand le changement disparaît à la synchro), supprimer, tout supprimer sauf les gardées, restaurer, filtres (toutes, non lues, gardées, notes, emploi du temps).
- **Compte (app web)** : carte « Session privée » (données uniquement dans ce navigateur, rien d'envoyé, app vide sur un autre ordinateur tant qu'on n'importe pas) et bouton d'envoi vers un autre appareil par QR animé (trames, comme l'APK).
- **Notes** : le texte du panneau Notes redevient lisible dans la démo du site (téléphone) ; nouvelle courbe « Évolution de la moyenne générale », elle s'élargit à chaque synchro qui apporte une note.
- **Site** : menu hamburger sur téléphone, colonne « Recommandé » (Extension) dans le comparatif, « Site » renommé « Aide », fiches de version avec date et heure de sortie, tutoriel d'installation précis avec captures qui s'agrandissent (croix pour fermer).

## 1.46.23 — mise à jour obligatoire et script de mise à jour

- **Mise à jour obligatoire (extension)** : tant que la version installée est plus ancienne que la dernière version publiée, une fenêtre plein écran verrouille le popup, l'agenda, les paramètres et le choix du design, et plus aucune synchro ne part. Elle ne se ferme pas (ni Échap, ni suppression dans la page) et revient si on quitte puis revient : l'état est recalculé à chaque ouverture, une panne réseau ne le lève pas. Inactive dans l'app web / l'APK et dans les paquets des magasins (ils se mettent à jour seuls).
- **maj-extension.bat** : script sans droits administrateur qui télécharge le ZIP officiel (HTTPS) et remplace les fichiers du dossier de l'extension ; il est aussi dans le ZIP, à côté de `manifest.json`.
- **Page de téléchargement** : captures du tutoriel d'installation (mode développeur, choix du dossier).

## 1.46.22 — nouveau look du site

- **Site et pages de téléchargement** : fond blanc, titres serrés très gras avec mot clé souligné, boutons bleus dégradés, maquettes de téléphone inclinées, apparition douce au défilement (désactivée si « réduire les animations »). Mode sombre conservé. Aucun appel réseau ni police externe ajouté.

## 1.46.21 — app Android 1.4.18 : compétences (UE)

- **Notes > 👁 Voir mes compétences** : la moyenne de chaque UE (« UE RT 1.1 - Assister l'administrateur du réseau ») calculée depuis les matières, en barres à la hauteur de la moyenne, avec un trait pointillé à 10 (seuil de validation). Semestres et années séparés, moyenne de chaque année et de chaque compétence sur l'année, liste « validée / sous 10 ».

## 1.46.20 — app Android 1.4.17 : légende des notes, mises à jour forcées

- **Notes** : légende des couleurs sous le graphique (vert 14 et plus, jaune 10 à 14, orange sous 10, gris moyenne de la classe). Dans le tableau, la note dont le barème peut changer (sur 20 ou sur N) est violette tant qu'on n'a pas répondu, rose ensuite.
- **Extension** : le code de déchiffrement est affiché sous « Générer le lien » (un clic le copie) et un bouton « Mises à jour » force la vérification ; les trois boutons sont sur la même ligne. Vérification automatique toutes les 5 minutes (au lieu de 20).
- **À faire et examens** : la date (jour, numéro, mois) s'affiche en plus de l'horaire pour les examens et les devoirs.
- **Mise à jour forcée** : dès qu'une nouvelle version est détectée, l'extension se recharge si le dossier est déjà à jour, sinon ouvre une fois par version la page de téléchargement qui lance le ZIP. Une extension en mode développeur ne peut pas se réécrire elle-même : il faut remplacer le dossier puis « Recharger ».

## 1.46.19 — app Android 1.4.16 : détail de note au premier plan

- **Notes** : la fenêtre de détail d'une évaluation passait derrière la liste des notes et se chevauchait avec elle ; elle s'ouvre maintenant au premier plan. Version web seule (mise à jour silencieuse).
- **Site** : nouvelle page « Télécharger l'extension » (`extension/`) avec le ZIP Chrome/Edge à charger en mode développeur ; le ZIP ne contient que le code, aucune donnée personnelle (`tests/gen_extension_page.py` le régénère à chaque version).
- **Pages de téléchargement** : choix « ZIP de l'extension », « APK » ou « les deux d'un coup », avec le poids en Mo affiché sur chaque bouton.

## 1.46.18 — iPhone : envoyer les données à l'app

- **Extension sur iPhone/iPad** : bouton « Envoyer les données à l'app » (feuille de partage + lien copié, code affiché), visible seulement si la page de l'app a déjà été ouverte dans ce navigateur et que des données existent. iOS ne permet pas de savoir si l'app est installée sur l'écran d'accueil : la détection repose sur cette ouverture, enregistrée localement, rien n'est envoyé à un tiers.

## 1.46.17 — app web : explication de la connexion Odin

- **Importer mes données (app web)** : explique pourquoi un navigateur ne peut pas se connecter à Odin (cookies isolés, fenêtre CAS dédiée, aucun serveur tiers) et, sur Android, propose l'APK qui se connecte directement comme l'extension.

## 1.46.16 — app Android 1.4.15 : barème sans doublon

- **Barème des évaluations** : l'intitulé affichait « (sur 22.0) (sur 22) » quand Odin sépare « sur » et le nombre par une espace insécable ; le barème d'origine est maintenant retiré dans tous les cas. Constaté sur le vrai téléphone ; test ajouté. Version web seule : installée sans APK.

## 1.46.15 — app Android 1.4.14 : jour férié lisible

- **Jour férié = aujourd'hui** : le numéro du jour courant restait rouge sur son fond coloré (illisible, ex. le 11 novembre) ; il garde maintenant sa couleur normale, l'infobulle indique toujours « férié ». Version web seule : installée sans APK (mise à jour silencieuse signée).

## 1.46.14 — app Android 1.4.13 : logo Université Clermont Auvergne

- **Logo de l'app** : l'icône de l'APK (lanceur carré et rond), de l'app web (iPhone/Android, icône d'installation, écrans de démarrage iOS) et de la page de téléchargement est maintenant le logo « Université Clermont Auvergne », fond blanc. L'extension garde son icône d'origine. Source : `app/icons/logo-uca-source.jpg`, générée par `tests/gen_uca_logo.py`.

## 1.46.13 — app Android 1.4.12 : barème des évaluations, mise à jour plus claire, carnet

- **Barème des évaluations (extension, app Android, app web iPhone/Android)** : une évaluation dont l'intitulé contient « (sur 12.0) », « (sur 25) »… est ambiguë (la note affichée est-elle déjà ramenée sur 20 ?). Pour chacune, deux boutons demandent « Cette note est sur combien ? » : « sur 20 » ou « sur 12 ». Le choix recalcule la moyenne de la matière, de l'UE et la moyenne générale (note × 20 ÷ barème, avec le coefficient), évaluation par évaluation. Une flèche ⇄ à côté de « (sur 12) » permet de rebasculer à tout moment. Choix gardé sur l'appareil et partagé avec l'app web et l'APK par l'export.
- **Écran de mise à jour de l'APK** : la liste des nouveautés défile et couvre toutes les versions publiées depuis celle installée (pas seulement la dernière) ; les boutons restent visibles en bas ; plus aucun bandeau « session expirée » par-dessus (d'abord la mise à jour, ensuite la connexion) ; l'APK téléchargé est supprimé après l'installation (à la mise à jour, au lancement suivant, et si on annule plus de 10 minutes après). Les versions qui ne changent que les pages (comme celle-ci pour l'extension et l'app web) passent par le paquet signé, sans installer d'APK.
- **App web (PWA)** : fenêtre « Nouvelle version disponible » (nouveautés défilantes, bouton « Mettre à jour maintenant » qui vide le cache et recharge) quand une version est publiée pendant que l'app est ouverte ; au premier lancement après une mise à jour, « Mise à jour installée » avec tout ce qui a changé. Même source que l'APK : `version.json` (champ `history`).
- **Carnet** : la marge rouge du relevé ne passe plus sur les premières lettres (le texte commence après, avec un petit espace) ; « Moyenne générale » et la note tiennent sur une ligne (aussi dans les 3 autres designs).

## 1.46.12 — app Android 1.4.11 : « Mes déclarations » dans les absences de l'app

- **App Android, onglet Absences** : la liste « Mes déclarations » (dates et horaires, motif, date de dépôt, statut Justifiée / Refusée / En attente) s'affiche comme dans l'extension. L'app ne lisait que les compteurs ; elle lit maintenant aussi la liste des déclarations d'Odin (même lecture que l'extension). Si Odin ne la montre pas, rien n'est inventé : seuls les compteurs restent.

## 1.46.11 — app Android 1.4.10 : cloche « Activité », fini les rafales de notifications

- **Cloche « Activité » dans l'agenda** (les 4 designs, entrée « Activité » dans le menu du téléphone) : à chaque synchronisation, tout ce qui s'est passé est gardé 30 jours et relisible : cours ajouté, annulé, déplacé, salle ou enseignant changé, nouvelle note, seuil d'absences atteint. Pastille rouge avec le nombre de nouveautés, remise à zéro à l'ouverture ; un clic sur un changement ouvre le jour concerné ; « Tout effacer » vide le journal. Les changements sur des cours déjà passés restent lisibles, marqués « passé », mais ne comptent pas comme nouveaux.
- **Notifications** : quand tu cliques sur « Synchroniser », plus aucune notification système (tu regardes l'écran, tout est dans la cloche). La synchro automatique envoie une seule notification groupée, uniquement pour les cours à venir.
- **Mise à jour de l'APK** : `version.json` annonçait un minimum trop bas, donc une app en 1.4.8 ne proposait jamais la 1.4.9. Corrigé (et testé) : les anciennes versions sont invitées à installer le nouvel APK.
- Données : `uca_activity` et `uca_activity_seen` sont exportées/importées avec le reste (téléphone, partage) et effacées par « Réinitialiser ».

## 1.46.10 — app Android 1.4.9 : app web identique à l'app Android, plus aucune donnée inventée

- **App web installable (Android et iPhone)** : même structure que l'app Android, barre du bas Accueil / Études / Agenda / Lieux / Compte, sous-écrans Notifications, Préférences, Scolarité, Stage et emploi, Bibliothèques, Transports, mêmes couleurs (`app/shell.html`). Accueil : statut réel des services et raccourcis ; Études : prochains cours ; Lieux : carte (avec accord) et itinéraires Google Maps / Waze / OpenStreetMap (et Plans sur iPhone) ; Compte : photo de profil gardée sur l'appareil, groupes, préférences, effacement des données ; Notifications : changements d'emploi du temps et nouvelles notes.
- **App web sur ordinateur** : mise en page de bureau (barre latérale à gauche au lieu de la barre du bas, écrans en deux colonnes, carte et liste des lieux côte à côte, agenda en pleine largeur, choix d'itinéraire en fenêtre centrale). Sur téléphone, mêmes écrans que l'APK.
- **Menu du téléphone** : l'entrée « Liste » avait une icône sans texte ; libellé ajouté dans les 4 designs.
- **Sécurité** : politique de sécurité (CSP) sur la coque de l'app web ; nouveau test : données piégées (groupes, changements, notes, profil) affichées sans jamais exécuter de script.
- Limites d'un navigateur (pas de contournement possible) : pas de connexion directe au CAS ni à Odin (les données arrivent par « Importer mes données »), pas de synchro ni de notification quand l'app est fermée, pas de widget ni de calendrier du téléphone.
- **App Android, données inventées retirées** : l'Accueil affichait « ● Ouvert » écrit en dur, « 3 mails non lus », des horaires de BU et un taux d'affluence ; la Scolarité un faux numéro étudiant et un faux INE, un bouton « certificat téléchargé » qui ne téléchargeait rien ; Stage et emploi de fausses offres ; Livres un faux historique. Remplacés par le statut réel des services (vérifié à l'ouverture), le vrai nombre de notifications et des liens vers les sites officiels (ENT, Odin, BU, offres de l'université, 1jeune1solution).

## 1.46.9 — app Android 1.4.8 : vue Liste, vue Jour en blocs, emploi du temps de la classe fiable

- **Nouvelle vue « Liste »** (bouton 📋 Liste, les 4 designs) : un jour sous forme de liste ; sur téléphone, glisser à gauche ou à droite change de jour. Raccourci clavier `L`.
- **Vue « Jour » en blocs** : même rendu que la vue 3 jours (blocs sur la grille horaire) mais un seul jour sur toute la largeur, glisser pour changer de jour. Le réglage « Vue à l'ouverture » propose « Liste (jour) » et « Jour (blocs) » ; sur téléphone la vue automatique reste la liste.
- **Emploi du temps de la classe (app)** : si aucune classe n'est sélectionnée dans ADE, l'app le dit (« Choisis ta classe dans ADE ») et lit le lien d'export toute seule dès qu'elle est choisie ; la progression bleue « EN DIRECT » ne reste jamais bloquée (fermeture garantie en cas d'échec ou de retour).
- **Vues 3 et 5 jours de la classe** : un même cours donné à plusieurs groupes en même temps devient une seule carte (profs et salles réunis) ; les cours simultanés partagent les colonnes au plus juste ; colonnes à largeur minimale avec défilement horizontal et heures fixes à gauche.

## 1.46.8 — notifications sans cours passés, jours passés conservés, note du carnet

- **Rappels de cours** : après plusieurs heures ou jours sans ouvrir le navigateur, Chrome et Firefox déclenchent d'un coup toutes les alarmes manquées au démarrage ; l'extension affichait alors « Dans 1 min : … » pour des cours passés. Un rappel n'est maintenant affiché que si le cours n'a pas commencé et si l'alarme n'a pas plus de 5 minutes de retard.
- **Changements d'emploi du temps** : seuls les cours à venir sont notifiés. Rappels de la veille (devoirs et examens) : ignorés s'ils arrivent avec plus de 6 h de retard.
- **Emploi du temps de toute la classe (ADE, edt.uca.fr)** : le filtre « Emploi du temps personnel » (Filtres) est coché par défaut (ton emploi du temps d'Odin). Décoché, l'agenda montre toute la classe, tous les groupes, comme si tout était coché. L'adresse de l'export iCalendar d'ADE se découvre une fois, dans une petite fenêtre de connexion CAS comme pour Odin (ADE ouvre « Exporter » puis « Générer URL » tout seul, rien à retaper si tu viens de te connecter) ; elle ne contient aucun jeton et l'export se relit ensuite sans cookie, à chaque synchro. Ton groupe est retrouvé grâce aux intitulés d'Odin (même jour, mêmes heures, même nom), et les jours passés qu'Odin n'a jamais renvoyés sont reconstitués à partir de la classe. Nouvelle permission : `https://edt.uca.fr/*`. Extension et app Android (la découverte de l'adresse dans l'app n'a pas été essayée avec une vraie session).
- **Les jours passés restent consultables** : une synchro ne remplace plus que les cours d'aujourd'hui et à venir ; les jours passés gardent ce que les synchros précédentes ont enregistré (400 jours d'historique au plus), dans l'extension et dans l'app Android. Un jour passé qu'Odin renvoie encore mais qu'on n'avait jamais vu est ajouté.
- **Graphique des notes** : la moyenne de chaque matière tient sur une seule ligne ; le graphique s'élargit avec le nombre de matières (défilement dans son cadre) ; la moyenne de la classe apparaît en barres claires dans chaque matière, avec un trait transparent pour la moyenne générale de la classe ; les matières sous le graphique sont cliquables : le panneau descend jusqu'à la matière, une flèche animée la désigne.
- **Panneau Notes sur téléphone** : largeur de l'écran moins 40 px, hauteur de l'écran moins 120 px, grande croix de fermeture, défilement dans le panneau, tableau qui défile dans son cadre.
- **Devoirs, examens, notes de cours** : un clic ouvre l'agenda sur le cours concerné, désigné par une flèche animée (examens du panneau Notes aussi). Les notes écrites sur les cours sont listées dans « Devoirs et examens ».
- **Design carnet** : la note personnelle s'écrit maintenant sur les lignes du papier (même hauteur de ligne pour le texte et les lignes, le papier défile avec le texte).
- **Nouvelle note** : la notification après synchro existait déjà (réglage « Nouvelle note », activé par défaut) ; elle est vérifiée par les tests.

## 1.46.7 — app Android 1.4.7 : l'APK de mise à jour est supprimé après l'installation

- Quand tu télécharges l'APK complet depuis l'écran de mise à jour et que tu l'installes, l'app supprime ensuite le fichier téléchargé au premier démarrage de la nouvelle version : il ne reste plus 5 Mo inutiles sur le téléphone.
- Les cookies de connexion de l'app sont aussi écrits sur le disque quand l'app s'arrête.
- **Diagnostic de connexion** (Préférences) : montre l'état de la session, les noms des cookies présents pour les sites de l'UCA (jamais leurs valeurs) et le journal des derniers contrôles, avec un bouton Copier pour un signalement.
- Ce correctif ne force pas la mise à jour : les 1.4.6 continuent de fonctionner, l'APK est proposé quand tu veux.

## 1.46.6 — app Android 1.4.6 : consultation hors session, graphique des notes, carte, notifications

- **Session expirée** : l'app reste entièrement consultable avec les données déjà synchronisées. Un bandeau rouge en bas à gauche dit « Session expirée. Veuillez vous reconnecter. » ; un bouton « Se connecter » est dans le menu de l'agenda et dans Compte. La messagerie, elle, redemande la connexion. La vérification de session teste la vraie page d'Odin et attend deux contrôles concordants avant d'afficher le bandeau.
- **Notes** : un clic sur « Moyenne générale » ouvre le graphique de toutes les matières, avec le trait pointillé horizontal de la moyenne générale et, dessous, les notes de chaque matière (vert ≥ 14, jaune de 10 à 14, orange < 10). Le graphique d'une matière montre aussi le trait de la moyenne générale.
- **Carte** : zoom et déplacement au doigt, fond OpenStreetMap ou Google Maps (sans clé d'API ; Google peut déposer des cookies), « Ouvrir avec Google Maps / Waze / OpenStreetMap » pour chaque lieu. Positions revérifiées dans OpenStreetMap (certaines étaient décalées de 200 m à 1 km) ; les horaires et taux d'affluence inventés sont supprimés.
- **Notifications** : vraies notifications seulement (nouveau mail reçu, nouvelle note) ; réglage « Nouveau mail reçu » dans les Préférences ; les lignes écrites en dur sont retirées.
- **Compte** : nom, prénom, date de naissance, numéro, formation, groupe et adresse @etu.uca.fr lus dans Odin avec la session de l'app (« non détecté » sinon), lien « Voir mon profil étudiant ». Photo de profil locale.
- **Préférences** : textes périmés corrigés, bouton de test du blocage réservé aux versions de test.
- Aucun cookie ni identifiant n'est lu ou copié par l'app : elle utilise la session de sa WebView.

## 1.46.5 — app Android 1.4.5 : session CAS fiable, design dans les Préférences

- **Session expirée à tort** : l'app te demandait de te reconnecter dès que tu la quittais, alors que la session CAS dure plusieurs jours. Elle ne déclare maintenant la session expirée que si Odin renvoie vraiment le formulaire de connexion (champ mot de passe), jamais pour une simple page intermédiaire ou un réseau lent ; en cas de doute, elle ne verrouille pas. La resynchro utilise les cookies de connexion de la WebView de l'app, que le système garde sur le disque (écriture forcée quand l'app passe en arrière-plan). L'app ne lit ni ne copie ces cookies.
- **Design de l'application** : Préférences → « Design », appliqué à l'agenda et mémorisé, y compris quand tu le changes depuis le menu de l'agenda. Les autres écrans de l'app gardent leur thème sombre.
- Cette version change le code natif : elle s'installe avec le nouvel APK (proposé par l'écran de mise à jour de l'app).

## 1.46.4 — glisser pour changer de période, un seul emoji (mise à jour automatique 1.4.4)

- **Glisser le doigt** vers la gauche ou la droite change de période sur téléphone dans toutes les vues : jour, 3 jours, 5 jours, 6 jours, semaine et mois, dans les 4 designs. Un geste commencé dans une zone qui défile elle-même à l'horizontale n'est pas pris pour un changement.
- **Un seul emoji** devant les entrées du menu (le design en mettait un, le menu en ajoutait un deuxième).
- Pour l'app Android, c'est une mise à jour des pages (paquet signé 1.4.4) : elle s'installe seule, sans nouvel APK.
- Tests : glissement dans les 6 vues des 4 designs et absence de double emoji (`tests/android_sync.py`).

## 1.46.3 — app Android 1.4.3 : profil fiable, bonhomme cliquable, photo, contrôle des mises à jour

- **Profil** : l'app affichait parfois le nom ou l'adresse d'un enseignant, lus dans l'emploi du temps. Elle ne retient plus que « Bonjour/Bienvenue + nom » et une adresse `@etu.uca.fr`, et ne fabrique plus d'adresse à partir du nom. Les profils déjà enregistrés sont effacés une fois, puis relus à la prochaine synchro.
- **Petit bonhomme** en haut à droite : il ouvre Mon compte, depuis tous les écrans.
- **Photo de profil** : dans Mon compte, touche la photo pour en choisir une dans ta galerie. Elle est réduite et gardée uniquement sur le téléphone, et effacée à la déconnexion.
- **Contrôle régulier des mises à jour** : l'app interroge GitHub toutes les 15 minutes tant qu'elle est ouverte, et toutes les heures même fermée (réseau requis). Une mise à jour signée des pages s'installe seule ; un nouvel APK est proposé à l'ouverture.
- Cette version change le code natif : elle s'installe avec le nouvel APK (les 1.4.2 continuent de fonctionner).

## 1.46.2 — app Android 1.4.2 : mise à jour automatique

- **Mise à jour automatique** : au lancement de l'app (puis au plus toutes les 30 minutes), elle lit `version.json` sur GitHub et, si une nouvelle version de l'interface existe, la télécharge et l'installe seule, sans retélécharger l'APK. Un message l'annonce et l'agenda se recharge.
- **Sécurité** : le paquet `ota-bundle.zip` doit être signé (`ota-bundle.sig`) avec la clé de signature de l'APK, qui reste sur l'ordinateur. L'app vérifie la signature avec son propre certificat, refuse tout retour en arrière, tout fichier hors du dossier de l'app et tout type de fichier inattendu. Les adresses sont écrites en dur dans l'app. Un dépôt GitHub piraté ne peut donc pas faire exécuter du code.
- Un changement du code natif (nouvel APK) reste proposé par l'écran d'installation.
- Pour publier une mise à jour de l'interface : `python -I -X utf8 tests/build_ota.py`, puis commit et push. La première installation de la 1.4.2 se fait à la main ; les suivantes sont automatiques.

## 1.46.1 — app Android : emploi du temps et session expirée

- **Emploi du temps de l'app** : l'app Android envoyait le texte brut de la page Odin, mais personne ne le transformait en cours, donc l'agenda restait vide après la synchro. Il est maintenant lu (comme dans l'extension) dans les 4 designs.
- **Session expirée** : l'app se verrouille entièrement (onglets et sous-écrans) et demande une nouvelle connexion CAS. Elle vérifie aussi la session en silence au retour dans l'app (au plus toutes les 5 minutes) ; si le réseau ne répond pas, elle ne bloque jamais.
- Aucun identifiant ni cookie n'est lu ou conservé par l'app : la connexion se fait dans la page officielle.
- Test : `tests/android_sync.py`.

## 1.46.0 — bugs graves, sécurité et ménage

- **Plus de fausse synchro** : sans extension, le site envoie vers l'import au lieu d'annoncer un succès sans rien récupérer. Le bouton Importer est de retour.
- **Liens utiles** : ils ouvrent le site publié depuis l'extension (ils menaient à une erreur dans le paquet magasin) ; le lien vers une page Mozilla inexistante est retiré.
- **Blocs de cours** : plus aucun texte coupé dans les 4 designs ; vue Jour en grille pour bulletin et professionnel.
- **Page transports** : elle ne tourne plus en boucle.
- **Sécurité** : pages protégées par une politique de contenu, fichiers importés vérifiés, fichier reçu importé seulement après confirmation.
- **App Android 1.4.0** : mises à jour à chaud non signées retirées, carte embarquée, profil effacé à la déconnexion.
- **Ménage** : images inutilisées et de droits douteux, doublons et aperçu de démo retirés. Politique de confidentialité mise à jour.
- Tests : plus aucun contact avec les vrais serveurs de l'UCA.

## 1.45.3 — design carnet rétabli

- Le design carnet avait perdu ses post-it pastel (couleurs vives illisibles, texte pâle) : sa palette, ses réglages de grille et ses textes d'origine sont restaurés.
- Accessibilité : le libellé de période de la vue semaine est maintenant repéré par les lecteurs d'écran.

## 1.45.2 — écran de mise à jour de l'app qui ne se fermait pas

- L'écran « Nouvelle version détectée » revenait en boucle sur le site et l'app : la version locale était figée à 1.1.0, donc « Mettre à jour » rechargeait sans rien changer. La version appliquée est maintenant mémorisée, et le bouton « Plus tard » (ex-« Mode Test Démo ») repousse l'écran jusqu'à la prochaine version.
- Extension : l'écran n'y est plus chargé (corrigé en 1.45.1). Si tu le vois encore, recharge l'extension après un `git pull`.

## 1.45.1 — paquets des magasins allégés

- Les paquets Firefox et Chrome n'embarquent plus l'APK, le bundle de mise à jour à chaud, la carte des campus ni les GIF de l'app (73 Mo → 2,5 Mo).
- L'écran de mise à jour GitHub de l'app n'est plus chargé dans l'extension : il bloquait l'agenda et n'a pas sa place dans un paquet de magasin.

## 1.44.0 — Odin en maintenance

Quand Odin affiche sa page « Site en maintenance. Les équipes sont mobilisées pour procéder aux opérations de mise à jour dans les meilleurs délais. Merci de ne pas ouvrir de ticket au support. » (souvent en http, sans HTTPS), l'extension le reconnaît comme une maintenance et non comme une panne ordinaire.
- **Ancienne synchro conservée** : ni l'emploi du temps, ni les notes, ni les absences ne sont touchés, et aucune fenêtre de connexion CAS ne s'ouvre pour rien.
- **Message clair** : « Odin est en maintenance : ancien emploi du temps conservé » dans la ligne d'info de l'agenda (4 designs), et dans les panneaux Notes et Absences.
- **Page en http** : l'hôte `http://odin.iut.uca.fr/*` est ajouté aux permissions (même hôte, uniquement pour lire cette page de maintenance servie sans HTTPS).
- Accessibilité : chaque grille horaire a un nom propre selon le nombre de jours affichés (plus de repères en double pour les lecteurs d'écran).
- Tests : pages de maintenance (https et http) pour l'emploi du temps, les notes et les absences ; tests d'images partagées et de l'app mobile qui ne dépendent plus du jour de la semaine (ils échouaient le week-end).

## 1.43.0 — site vitrine (lot 4)

Déjà en place (vérifié, non refait) : accueil avec comparatif des quatre façons d'utiliser le projet, aide complète de plus de cinquante questions avec recherche, page de confidentialité, 404.

Ajouté :
- **Démo interactive** sur l'accueil : le vrai agenda des quatre designs, téléphone ou ordinateur, avec des données inventées (`core/demo.js`, calées sur la semaine en cours). Aucune requête hors du site, stockage de session à part (le stockage réel de l'app n'est jamais touché), « Synchroniser » simulé, aucune page de la démo ne peut sortir du cadre. Le cadre ne se charge que quand la section devient visible.
- **FAQ** de six questions sur l'accueil (avec données structurées FAQPage) ; l'aide complète reste la référence.
- **« Quoi de neuf »** généré depuis `UPDATES.md` : page `nouveautes.html` et trois dernières versions sur l'accueil (`python -I -X utf8 tests/gen_news.py`, `--check` en test et en CI). Aucun script côté visiteur.
- **Version anglaise** `/en/` de l'accueil (présentation, comparatif, FAQ, démo) avec `hreflang` ; l'aide, les nouveautés et les applications restent en français, ce qui est indiqué sur la page.
- **Référencement et partage** : `canonical`, balises Open Graph et Twitter, image de partage 1200×630 (`tests/gen_og.py`), `sitemap.xml`, `robots.txt`.
- **Captures à jour** (sélecteur de design, fiches des magasins avec la liste des devoirs) ; fiches AMO / Chrome et notes du relecteur mises à jour (4 designs, devoirs, partage en image, confidentialité des devoirs).
- Accessibilité du site : `tests/a11y.py` audite aussi l'accueil, la version anglaise, les nouveautés et l'aide (ordinateur et téléphone) : nom du lien de marque, en-tête de tableau, zone de défilement du comparatif atteignable au clavier (32/32).
- Tests : `tests/pwa.py` couvre la démo (4 designs, téléphone, hors-ligne de l'app intact, aucune requête externe), l'anglais, les métadonnées, les nouveautés et le sitemap.

